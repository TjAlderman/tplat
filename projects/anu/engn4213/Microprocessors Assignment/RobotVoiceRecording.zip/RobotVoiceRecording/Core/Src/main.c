/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "fatfs_sd.h"
#include "string.h"
#include <arm_math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ADC_BUF_LEN 4096
#define MAX_SAMPLES 12288
#define FFT_SIZE 1024
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim5;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

char buffer_uart[100]; //writing buffer_uart
UINT br, bw;  // File read/write count

// raw microphone output
uint16_t adc_buf[ADC_BUF_LEN];

// microphone output split into 8-bit values
uint8_t adc_buf_8bit1[ADC_BUF_LEN], adc_buf_8bit2[ADC_BUF_LEN];

// recording array to write to SD card
uint16_t recording[ADC_BUF_LEN*3];
uint16_t robotrecording[ADC_BUF_LEN*3];
uint16_t test=0; // delete later, used as a watch
uint16_t max_val=0; // delete later, used as a watch
uint16_t max_val_index=0; // delete later, used as a watch
uint32_t max_freq=0;

uint16_t buffersize=0;
char current_value[8];
char robot_value[8];
char fourier_value[20];
char max_frequency[20];
char txtRecording[ADC_BUF_LEN*3];

// flag to tell when microphone output buffer is half full/full
int flag;
int recordflag=0;
int pulse;
uint16_t recording_index=0;

//FIR filter stuff

// filter coefficients
#define FILTER_TAP_NUM 5
float32_t fir_coeffs[FILTER_TAP_NUM] = {
  -0.01238356,
  -0.1033217,
   0.81812371,
  -0.1033217,
  -0.01238356
//   0.02840647,
//   -0.23700821,
//   0.46917063,
//   -0.23700821,
//   0.02840647
};

//#define FILTER_TAP_NUM 9
//float32_t fir_coeffs[FILTER_TAP_NUM] = {
//-0.00375639, -0.0217521,  -0.08205248, -0.16251428,  0.80308498, -0.16251428,
// -0.08205248, -0.0217521,  -0.00375639
// };




// filtered outputs (input is adc_buf[])
uint16_t filtered_adc_buf1[ADC_BUF_LEN/2], filtered_adc_buf2[ADC_BUF_LEN/2];

// a state buffer (stores old values from filter
float32_t fir_state[ADC_BUF_LEN/2+FILTER_TAP_NUM-1];

// create a fir filter instance
arm_fir_instance_f32 fir_filter;

// Fourier stuff
uint32_t fourier_output[FFT_SIZE];
arm_rfft_fast_instance_f32 S; // RFFT instance

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_SPI2_Init(void);
static void MX_TIM3_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM5_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
FRESULT open_append(FIL* fp, const char* path);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
FATFS fs;  // file system
FIL fil; // File
FIL recordingFil;
FIL robotrecordingFil;
FIL fourierrecordingFil;
FILINFO fno;
FRESULT fresult;  // result
FRESULT fresultnew;  // result
FRESULT recordingFilresult;

/**** capacity related *****/
FATFS *pfs;
DWORD fre_clust;
uint32_t total, free_space;

void send_uart(char*string)
{
	uint8_t len=strlen(string);
	HAL_UART_Transmit(&huart2, (uint8_t*) string, len, 2000);
}

int bufsize (char*buf)
{
	int i=0;
	while(*buf++ !='\0') i++;
	return i;
}

int bufsize_16bit (uint16_t*buf)
{
	int i=0;
	while(*buf++ !='\0') i++;
	return i;
}

void bufclear (char *buffer_uart)
{
	for (int i=0; i<sizeof(buffer_uart); i++)
	{
		buffer_uart[i]='\0';
	}
}

FRESULT open_append(FIL* fp, /* [OUT] File object to create */
const char* path /* [IN]  File name to be opened */
) {

	/* Opens an existing file. If not exist, creates a new file. */
	fresult = f_open(fp, path, FA_WRITE | FA_OPEN_ALWAYS | FA_WRITE);
	if (fresult == 0) {
		/* Seek to end of the file to append data */
		fresult = f_lseek(fp, f_size(fp));
		if (fresult != 0)
			f_close(fp);
	}
	return fresult;
}

void storeData(uint16_t* source, uint8_t* destination, size_t sourceSize) {
	for (size_t i = 0; i < sourceSize; i++) {
        destination[2*i] = (uint8_t)(source[i] >> 8);  // Store the LSB 8 bits
        destination[2*i+1] = (uint8_t)(source[i]);  // Store the MSB 8 bits
    }
}

void inttoChar(uint16_t* input, char* output, size_t inputSize) {
	for (uint16_t i=0; i < inputSize; i++) {
		output[i] = ((char)(input[i]))+0x30;
	}
}

void apply_high_pass_filter(uint16_t* input, uint16_t* output) {
    float32_t temp_input[ADC_BUF_LEN/2];
    float32_t temp_output[ADC_BUF_LEN/2];

    // Convert input array to float32_t
    for (uint32_t i = 0; i < ADC_BUF_LEN/2; i++) {
        temp_input[i] = (float32_t)input[i]; // use typecasting to convert each value to float32_t
    }

    // Perform the FIR filtering
    arm_fir_f32(&fir_filter, &temp_input, &temp_output, ADC_BUF_LEN/2);

    // Convert output array to uint16_t
    for (uint32_t i = 0; i < ADC_BUF_LEN/2; i++) {
        output[i] = (uint16_t)temp_output[i]; // use typecasting to convert each value back to uint16_t
    }
}

uint32_t apply_FFT(uint16_t* input, uint32_t* output) {

	// perform the real FFT over sections of the input array
	uint32_t num_of_samples = 1024;
	//uint32_t num_of_iterations = ADC_BUF_LEN*3/num_of_samples;
	uint32_t num_of_iterations = 1;
	uint32_t max_value=0;

	for (uint32_t i = 0; i < num_of_iterations; i++){
		float32_t temp_output[FFT_SIZE*2];
		float32_t current_block[num_of_samples];
		for (uint32_t k = 0; k < num_of_samples; k++) current_block[k] = (float32_t)input[k*(num_of_iterations+1)];
		arm_rfft_fast_f32(&S, current_block, temp_output, 0);
		for (uint32_t k = 0; k < FFT_SIZE*2; k+=2) {
			output[k/2] = (uint32_t)20*log10f(sqrtf(temp_output[k]*temp_output[k]+temp_output[k+1]*temp_output[k+1]));
			//output[k/2] += (uint32_t)(sqrtf(temp_output[k]*temp_output[k]+temp_output[k+1]*temp_output[k+1]));
			if (k==0) output[k] = 0; // remove the DC bias value
			if ((k/2)<(FFT_SIZE/2)) {
				if (output[k/2]>max_value) max_value=k/2;
			}
		}
	}
	return max_value;
}

void append_to_buffer(uint16_t* output, uint16_t* input) {
	for (uint32_t i=0; i<ADC_BUF_LEN/2; i++){
		output[(recording_index)*(ADC_BUF_LEN/2)+i] = input[i];
	}
}

void writeSD(uint16_t* input, size_t inputSize) {
	fresult= open_append(&recordingFil,"recording.txt");
	buffersize = sizeof(input);
	for (uint16_t i=0; i < 12288; i++) {
		//char current_value[5];
		// converts the values to writeable characters with a , at the end (e.g. if recording[0] = 28 we want a char array that looks like 28,
		snprintf(current_value, sizeof(current_value), "%u,", input[i]);
		if(fresult == FR_OK) {
			fresult = f_write(&recordingFil,current_value, bufsize(current_value), &bw);
		}
		test++;
	}
	fresult = f_close(&recordingFil);
}

void writerobotSD(uint16_t* input) {
	fresult= open_append(&robotrecordingFil,"robotrecording.txt");
	for (uint16_t i=0; i < 12288; i++) {
		snprintf(robot_value, sizeof(robot_value), "%u,", input[i]);
		if(fresult == FR_OK) {
			fresult = f_write(&robotrecordingFil,robot_value, bufsize(robot_value), &bw);
		}
		test++;
	}
	fresult = f_close(&robotrecordingFil);
}

void writeFourierSD(uint32_t* input) {
	fresult= open_append(&fourierrecordingFil,"recordingfreqspectrum.txt");
	for (uint32_t i=0; i < FFT_SIZE; i++) {
		snprintf(fourier_value, sizeof(fourier_value), "%u,", input[i]);
		if(fresult == FR_OK) {
			fresult = f_write(&fourierrecordingFil,fourier_value, bufsize(fourier_value), &bw);
		}
		test++;
	}
	fresult = f_close(&fourierrecordingFil);
}

void robotvoice(uint16_t* input, uint16_t* robotrecording) {

	for (int i = 0; i < MAX_SAMPLES - 400; i++) {
			 robotrecording[i] = (input[i] + input[i + 200] + input[i + 400]);
		}
}

//LCD Configuration//

uint8_t Buffer[25] = {0};
uint8_t BufferMSG[] = "Please Help,";
uint8_t privacyq[] = "Privacy Mode?";
uint8_t privacy[] = "Privacy Mode";
uint8_t active[] = "Activated";
uint8_t deactive[] = "Deactivated";
uint8_t press[] = "Press";
uint8_t blue[] = "Blue Button";
uint8_t hz[] = "Hz";


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_SPI2_Init();
  MX_FATFS_Init();
  MX_TIM3_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_USART1_UART_Init();
  MX_TIM5_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */

  //Initialise LCD Screen//

   lcd_init(0x27);
   HAL_Delay(2000);


  /* Mount SD card*/
    fresult = f_mount(&fs, "/", 1);


   // initialise the highpass FIR filter
   arm_fir_init_f32(&fir_filter, FILTER_TAP_NUM, fir_coeffs, fir_state, ADC_BUF_LEN/2);

   // initialise the real FFT
   arm_rfft_fast_init_f32(&S, FFT_SIZE /*bin count*/);

   // start the timer that triggers ADC sampling
   HAL_TIM_Base_Start_IT (&htim2);

   // start ADC DMA
   HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buf, ADC_BUF_LEN);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  lcd_clear();
	  HAL_Delay(100);
	  lcd_send_string(privacyq);
	  HAL_Delay(3000);
	  lcd_clear();
	  HAL_Delay(100);
	  lcd_send_string(press);
	  HAL_Delay(100);
	  lcd_send_cmd(0xC0,4);
	  HAL_Delay(100);
	  lcd_send_string(blue);
	  HAL_Delay(3000);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */
  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T2_TRGO;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 48-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1000-1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_ENABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 41999;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 99;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 38399;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 14999;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 12499;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim5, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */
  HAL_TIM_MspPostInit(&htim5);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD2_Pin|external_LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SPI2_CS_GPIO_Port, SPI2_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD2_Pin external_LED_Pin */
  GPIO_InitStruct.Pin = LD2_Pin|external_LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : SPI2_CS_Pin */
  GPIO_InitStruct.Pin = SPI2_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SPI2_CS_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{

}

void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim5) {
	// stop recording
	recordflag = 0;
}

// Called when first half of buffer is filled
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc) {
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);
	// Apply low-pass filtering
	apply_high_pass_filter(&adc_buf, &filtered_adc_buf1);
	// store the result as 8-bit and transmit over UART
	storeData(&filtered_adc_buf1, &adc_buf_8bit1, ADC_BUF_LEN/2);
	flag = 0;
	HAL_UART_Transmit(&huart2,adc_buf_8bit1,ADC_BUF_LEN,100);
	// if recording, increment the recording index (ensures we don't overwrite any values in the recording array)
	if (recordflag==1) {
		recording_index++;
	}
}

// Called when buffer is completely filled
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
	HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
	// Apply low-pass filtering
	apply_high_pass_filter(&adc_buf[((ADC_BUF_LEN/2)-1)], &filtered_adc_buf2);
	// store the result as 8-bit and transmit over UART
	storeData(&filtered_adc_buf2, &adc_buf_8bit2, ADC_BUF_LEN/2);
	flag = 1;
	HAL_UART_Transmit(&huart2,adc_buf_8bit2,ADC_BUF_LEN,100);
	// if recording, increment the recording index (ensures we don't overwrite any values in the recording array)
	if (recordflag==1) {
			recording_index++;
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	//LCD Approval of Callback
	lcd_clear();
	HAL_Delay(100);
	lcd_send_string(privacy);
	HAL_Delay(100);
	lcd_send_cmd(0xC0,4);
	HAL_Delay(100);
	lcd_send_string(active);
	HAL_Delay(3000);

	// turn on an LED to indicate recording is live
	HAL_GPIO_WritePin(external_LED_GPIO_Port, GPIO_PIN_6, GPIO_PIN_SET);
	// start a timer that is used to define recording length
	recordflag = 1;
	HAL_TIM_PWM_Start_IT (&htim5, TIM_CHANNEL_2);
	HAL_TIM_Base_Start(&htim5);
	while(recordflag==1) {
		if(flag==0){
			append_to_buffer(&recording, &filtered_adc_buf1);
		}
		if(flag==1) {
			append_to_buffer(&recording, &filtered_adc_buf2);
		}
	}

	// apply the robot effect to the recording
	robotvoice(&recording, &robotrecording);

	// write original recording to the SD card
	writeSD(&recording, sizeof(recording));
	// write delayed robot voice to SD Card
	writerobotSD(&robotrecording);

	// perform FFT of recording and write to SSD
	max_freq = apply_FFT(&recording,&fourier_output);
	snprintf(max_frequency, sizeof(max_frequency), "%u,", max_freq);
	max_freq = 0;

	// LCD showing Max Freq
	lcd_clear();
	HAL_Delay(100);
	lcd_send_string(max_frequency);
	HAL_Delay(100);
	lcd_send_string(hz);
	HAL_Delay(4000);
	lcd_clear();
	HAL_Delay(100);

	writeFourierSD(&fourier_output);

	// clear the recording buffer
	// bufclear(recording);
	// reset the timers
	HAL_TIM_PWM_Stop_IT (&htim5, TIM_CHANNEL_2);
	HAL_TIM_Base_Stop(&htim5);
	// turn off the LED
	HAL_GPIO_WritePin(external_LED_GPIO_Port, GPIO_PIN_6, GPIO_PIN_RESET);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
